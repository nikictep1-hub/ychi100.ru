// Enhanced JavaScript for BlueTutor website

document.addEventListener('DOMContentLoaded', function() {
    // Initialize all functionality
    initPreloader();
    initNavigation();
    initTheme();
    initMobileMenu();
    initAnimations();
    initSearch();
    initTutorButtons();
    initSmoothScrolling();
    initCalculator();
    initQuiz();
    initCarousel();
    initNewsletter();
    initCookieConsent();
    initAuthSystem();
    initModals();
    initBackToTop();
    initStatsCounter();
    initOnlineStatus();
    initBlogArticles();
    updateUIAfterAuth();
});

// Preloader
function initPreloader() {
    const preloader = document.querySelector('.preloader');
    window.addEventListener('load', function() {
        setTimeout(() => {
            preloader.classList.add('hidden');
            setTimeout(() => {
                preloader.style.display = 'none';
            }, 500);
        }, 1000);
    });
}

// Enhanced Navigation
function initNavigation() {
    const header = document.querySelector('header');
    const navLinks = document.querySelectorAll('.nav-link');
    
    // Header background on scroll
    window.addEventListener('scroll', function() {
        if (window.scrollY > 100) {
            header.style.background = 'rgba(37, 99, 235, 0.95)';
            header.style.backdropFilter = 'blur(10px)';
        } else {
            header.style.background = 'var(--gradient)';
            header.style.backdropFilter = 'none';
        }
        
        // Update active nav link
        updateActiveNavLink();
    });
    
    // Update active nav link based on scroll position
    function updateActiveNavLink() {
        const sections = document.querySelectorAll('section');
        let currentSection = '';
        
        sections.forEach(section => {
            const sectionTop = section.offsetTop - 100;
            const sectionHeight = section.clientHeight;
            if (window.scrollY >= sectionTop && window.scrollY < sectionTop + sectionHeight) {
                currentSection = section.getAttribute('id');
            }
        });
        
        navLinks.forEach(link => {
            link.classList.remove('active');
            if (link.getAttribute('href') === `#${currentSection}`) {
                link.classList.add('active');
            }
        });
    }
}

// Theme Toggle
function initTheme() {
    const themeToggle = document.querySelector('.theme-toggle');
    const themeIcon = themeToggle.querySelector('i');
    
    // Check for saved theme preference
    const savedTheme = localStorage.getItem('theme') || 'light';
    if (savedTheme === 'dark') {
        document.body.classList.add('dark-theme');
        themeIcon.classList.replace('fa-moon', 'fa-sun');
    }
    
    themeToggle.addEventListener('click', function() {
        document.body.classList.toggle('dark-theme');
        
        if (document.body.classList.contains('dark-theme')) {
            localStorage.setItem('theme', 'dark');
            themeIcon.classList.replace('fa-moon', 'fa-sun');
        } else {
            localStorage.setItem('theme', 'light');
            themeIcon.classList.replace('fa-sun', 'fa-moon');
        }
    });
}

// Mobile Menu
function initMobileMenu() {
    const mobileMenuBtn = document.querySelector('.mobile-menu-btn');
    const mobileMenu = document.querySelector('.mobile-menu');
    const mobileMenuClose = document.querySelector('.mobile-menu-close');
    const mobileNavLinks = document.querySelectorAll('.mobile-nav-link');
    
    mobileMenuBtn.addEventListener('click', function() {
        mobileMenu.classList.add('active');
        document.body.style.overflow = 'hidden';
    });
    
    mobileMenuClose.addEventListener('click', closeMobileMenu);
    
    mobileNavLinks.forEach(link => {
        link.addEventListener('click', closeMobileMenu);
    });
    
    function closeMobileMenu() {
        mobileMenu.classList.remove('active');
        document.body.style.overflow = '';
    }
}

// Enhanced Animations
function initAnimations() {
    const animatedElements = document.querySelectorAll('.feature-card, .subject-card, .tutor-card, .review-card, .blog-card, .step');
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('visible');
                
                // Add staggered animation for steps
                if (entry.target.classList.contains('step')) {
                    const delay = Array.from(entry.target.parentElement.children).indexOf(entry.target) * 200;
                    entry.target.style.transitionDelay = `${delay}ms`;
                }
            }
        });
    }, { 
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    });
    
    animatedElements.forEach(element => {
        element.classList.add('fade-in');
        observer.observe(element);
    });
}

// Enhanced Search with Suggestions
function initSearch() {
    const searchInput = document.querySelector('#quick-search');
    const searchBtn = document.querySelector('#search-btn');
    const suggestionsContainer = document.querySelector('.search-suggestions');
    
    const subjects = [
        'математика', 'английский язык', 'физика', 'химия',
        'программирование', 'русский язык', 'биология', 'история',
        'обществознание', 'география', 'литература', 'информатика'
    ];
    
    searchInput.addEventListener('input', function() {
        const query = this.value.toLowerCase();
        suggestionsContainer.innerHTML = '';
        
        if (query.length > 1) {
            const filtered = subjects.filter(subject => 
                subject.toLowerCase().includes(query)
            );
            
            if (filtered.length > 0) {
                filtered.forEach(subject => {
                    const div = document.createElement('div');
                    div.className = 'suggestion-item';
                    div.textContent = subject;
                    div.addEventListener('click', function() {
                        searchInput.value = subject;
                        suggestionsContainer.classList.remove('show');
                        performSearch(subject);
                    });
                    suggestionsContainer.appendChild(div);
                });
                suggestionsContainer.classList.add('show');
            } else {
                suggestionsContainer.classList.remove('show');
            }
        } else {
            suggestionsContainer.classList.remove('show');
        }
    });
    
    searchBtn.addEventListener('click', function() {
        performSearch(searchInput.value.trim());
    });
    
    searchInput.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            performSearch(this.value.trim());
        }
    });
    
    // Close suggestions when clicking outside
    document.addEventListener('click', function(e) {
        if (!searchInput.contains(e.target) && !suggestionsContainer.contains(e.target)) {
            suggestionsContainer.classList.remove('show');
        }
    });
}

function performSearch(query) {
    if (query !== '') {
        // In a real application, this would make an API call
        showSearchResults(query);
    } else {
        showNotification('Пожалуйста, введите предмет для поиска', 'warning');
    }
}

function showSearchResults(query) {
    const results = [
        'математика', 'английский', 'физика', 'химия', 
        'программирование', 'русский язык', 'биология'
    ];
    
    if (results.some(subject => subject.includes(query.toLowerCase()))) {
        showNotification(`Найдены репетиторы по предмету: "${query}"`, 'success');
        // In real app, would redirect to search results page
    } else {
        showNotification(`К сожалению, репетиторов по предмету "${query}" не найдено. Попробуйте другой предмет.`, 'info');
    }
}

// Enhanced Tutor Booking
function initTutorButtons() {
    document.addEventListener('click', function(e) {
        if (e.target.classList.contains('tutor-button')) {
            const tutorCard = e.target.closest('.tutor-card');
            const tutorName = tutorCard.querySelector('h3').textContent;
            const tutorSubject = tutorCard.querySelector('.tutor-subject').textContent;
            
            // Add click animation
            e.target.style.transform = 'scale(0.95)';
            setTimeout(() => {
                e.target.style.transform = '';
            }, 150);
            
            showBookingModal(tutorName, tutorSubject);
        }
    });
}

function showBookingModal(tutorName, subject) {
    if (!isAuthenticated()) {
        showNotification('Пожалуйста, войдите в систему для записи на занятие', 'warning');
        document.querySelector('#login-modal').classList.add('active');
        return;
    }
    
    showNotification(`Запись на урок к ${tutorName} (${subject}). Мы свяжемся с вами в ближайшее время для подтверждения времени занятия!`, 'success');
}

// Smooth Scrolling
function initSmoothScrolling() {
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                const headerHeight = document.querySelector('header').offsetHeight;
                const targetPosition = target.offsetTop - headerHeight;
                
                window.scrollTo({
                    top: targetPosition,
                    behavior: 'smooth'
                });
            }
        });
    });
}

// Pricing Calculator
function initCalculator() {
    const subjectSelect = document.querySelector('#subject-select');
    const levelSelect = document.querySelector('#level-select');
    const lessonsRange = document.querySelector('#lessons-range');
    const lessonsValue = document.querySelector('#lessons-value');
    const durationButtons = document.querySelectorAll('.duration-btn');
    const calculatedPrice = document.querySelector('#calculated-price');
    const lessonPriceElement = document.querySelector('#lesson-price');
    const monthLessonsElement = document.querySelector('#month-lessons');
    const totalPriceElement = document.querySelector('#total-price');
    
    // Price matrix [subject][level]
    const priceMatrix = {
        math: { school: 1000, university: 1200, exam: 1500 },
        english: { school: 1200, university: 1400, exam: 1600 },
        physics: { school: 1100, university: 1300, exam: 1500 },
        programming: { school: 1300, university: 1500, exam: 1800 }
    };
    
    let currentDuration = 1;
    
    // Update lessons value display
    lessonsRange.addEventListener('input', function() {
        const value = this.value;
        lessonsValue.textContent = `${value} ${getLessonWord(value)}`;
        calculatePrice();
    });
    
    // Duration buttons
    durationButtons.forEach(button => {
        button.addEventListener('click', function() {
            durationButtons.forEach(btn => btn.classList.remove('active'));
            this.classList.add('active');
            currentDuration = parseInt(this.dataset.months);
            calculatePrice();
        });
    });
    
    // Calculate price when any input changes
    [subjectSelect, levelSelect].forEach(select => {
        select.addEventListener('change', calculatePrice);
    });
    
    function calculatePrice() {
        const subject = subjectSelect.value;
        const level = levelSelect.value;
        const lessonsPerWeek = parseInt(lessonsRange.value);
        const lessonsPerMonth = lessonsPerWeek * 4;
        
        const lessonPrice = priceMatrix[subject][level];
        const monthlyPrice = lessonPrice * lessonsPerMonth;
        const totalPrice = monthlyPrice * currentDuration;
        
        // Update displays
        lessonPriceElement.textContent = `${lessonPrice.toLocaleString()} руб`;
        monthLessonsElement.textContent = lessonsPerMonth;
        calculatedPrice.textContent = Math.round(monthlyPrice).toLocaleString();
        totalPriceElement.textContent = `${Math.round(totalPrice).toLocaleString()} руб`;
    }
    
    function getLessonWord(count) {
        if (count === 1) return 'занятие';
        if (count >= 2 && count <= 4) return 'занятия';
        return 'занятий';
    }
    
    // Initial calculation
    calculatePrice();
}

// Interactive Quiz
function initQuiz() {
    const quizData = [
        {
            question: "Какова ваша основная цель обучения?",
            options: [
                "Подготовка к экзаменам (ЕГЭ, ОГЭ)",
                "Повышение успеваемости в школе/вузе",
                "Профессиональное развитие",
                "Для себя, личный интерес"
            ]
        },
        {
            question: "Какой у вас текущий уровень знаний?",
            options: [
                "Начинающий с нуля",
                "Базовые знания",
                "Средний уровень",
                "Продвинутый уровень"
            ]
        },
        {
            question: "Какой формат занятий предпочитаете?",
            options: [
                "Индивидуальные занятия",
                "Занятия в мини-группе (2-4 человека)",
                "Групповые занятия",
                "Не имеет значения"
            ]
        },
        {
            question: "Как часто готовы заниматься?",
            options: [
                "1-2 раза в неделю",
                "3-4 раза в неделю",
                "5+ раз в неделю",
                "Пока не определился(ась)"
            ]
        },
        {
            question: "Какой бюджет планируете на обучение?",
            options: [
                "До 5 000 руб/мес",
                "5 000 - 10 000 руб/мес",
                "10 000 - 20 000 руб/мес",
                "Более 20 000 руб/мес"
            ]
        }
    ];
    
    let currentQuestion = 0;
    const answers = [];
    
    const questionText = document.querySelector('#quiz-question-text');
    const optionsContainer = document.querySelector('.quiz-options');
    const prevBtn = document.querySelector('.quiz-btn.prev');
    const nextBtn = document.querySelector('.quiz-btn.next');
    const progressFill = document.querySelector('.progress-fill');
    const progressText = document.querySelector('.progress-text');
    
    function loadQuestion() {
        const question = quizData[currentQuestion];
        questionText.textContent = question.question;
        
        optionsContainer.innerHTML = '';
        question.options.forEach((option, index) => {
            const optionElement = document.createElement('div');
            optionElement.className = 'quiz-option';
            if (answers[currentQuestion] === index) {
                optionElement.classList.add('selected');
            }
            optionElement.textContent = option;
            optionElement.addEventListener('click', () => selectOption(index));
            optionsContainer.appendChild(optionElement);
        });
        
        // Update progress
        const progress = ((currentQuestion + 1) / quizData.length) * 100;
        progressFill.style.width = `${progress}%`;
        progressText.textContent = `Вопрос ${currentQuestion + 1} из ${quizData.length}`;
        
        // Update buttons
        prevBtn.disabled = currentQuestion === 0;
        nextBtn.textContent = currentQuestion === quizData.length - 1 ? 'Завершить' : 'Далее';
    }
    
    function selectOption(optionIndex) {
        answers[currentQuestion] = optionIndex;
        const options = optionsContainer.querySelectorAll('.quiz-option');
        options.forEach((option, index) => {
            option.classList.toggle('selected', index === optionIndex);
        });
        nextBtn.disabled = false;
    }
    
    prevBtn.addEventListener('click', function() {
        if (currentQuestion > 0) {
            currentQuestion--;
            loadQuestion();
        }
    });
    
    nextBtn.addEventListener('click', function() {
        if (answers[currentQuestion] === undefined) {
            showNotification('Пожалуйста, выберите вариант ответа', 'warning');
            return;
        }
        
        if (currentQuestion < quizData.length - 1) {
            currentQuestion++;
            loadQuestion();
            nextBtn.disabled = true;
        } else {
            showQuizResults();
        }
    });
    
    function showQuizResults() {
        // Simple recommendation based on answers
        const recommendations = {
            0: "Рекомендуем интенсивный курс подготовки с фокусом на экзаменационные задания",
            1: "Подойдет стандартный курс с упором на школьную/вузовскую программу",
            2: "Специализированный курс с практическими заданиями и кейсами",
            3: "Общеобразовательный курс с гибким графиком и интересной подачей"
        };
        
        const mainGoal = answers[0];
        const recommendation = recommendations[mainGoal] || "Рекомендуем пройти бесплатную консультацию для подбора оптимального курса";
        
        showNotification(`Тест завершен! ${recommendation}`, 'success');
        
        // Reset quiz
        currentQuestion = 0;
        answers.length = 0;
        loadQuestion();
        nextBtn.disabled = true;
    }
    
    // Initial load
    loadQuestion();
}

// Tutors Carousel
function initCarousel() {
    const track = document.querySelector('.tutors-track');
    const prevBtn = document.querySelector('.carousel-btn.prev');
    const nextBtn = document.querySelector('.carousel-btn.next');
    const indicators = document.querySelector('.carousel-indicators');
    
    let currentSlide = 0;
    const slidesToShow = 3;
    const tutorCards = document.querySelectorAll('.tutors-track .tutor-card');
    const totalSlides = Math.ceil(tutorCards.length / slidesToShow);
    
    function updateCarousel() {
        const translateX = -currentSlide * (100 / slidesToShow);
        track.style.transform = `translateX(${translateX}%)`;
        
        // Update indicators
        document.querySelectorAll('.carousel-indicator').forEach((indicator, index) => {
            indicator.classList.toggle('active', index === currentSlide);
        });
        
        // Update button states
        prevBtn.disabled = currentSlide === 0;
        nextBtn.disabled = currentSlide === totalSlides - 1;
    }
    
    function goToSlide(slideIndex) {
        currentSlide = Math.max(0, Math.min(slideIndex, totalSlides - 1));
        updateCarousel();
    }
    
    prevBtn.addEventListener('click', function() {
        goToSlide(currentSlide - 1);
    });
    
    nextBtn.addEventListener('click', function() {
        goToSlide(currentSlide + 1);
    });
    
    // Create indicators
    indicators.innerHTML = '';
    for (let i = 0; i < totalSlides; i++) {
        const indicator = document.createElement('div');
        indicator.className = `carousel-indicator ${i === 0 ? 'active' : ''}`;
        indicator.addEventListener('click', () => goToSlide(i));
        indicators.appendChild(indicator);
    }
    
    // Initial setup
    updateCarousel();
    
    // Auto-advance carousel
    setInterval(() => {
        if (currentSlide < totalSlides - 1) {
            goToSlide(currentSlide + 1);
        } else {
            goToSlide(0);
        }
    }, 5000);
}

// Newsletter
function initNewsletter() {
    const newsletterForm = document.querySelector('.newsletter-form');
    const emailInput = document.querySelector('#newsletter-email');
    const submitBtn = document.querySelector('#newsletter-submit');
    
    newsletterForm.addEventListener('submit', function(e) {
        e.preventDefault();
        const email = emailInput.value.trim();
        
        if (validateEmail(email)) {
            // Simulate API call
            submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i>';
            submitBtn.disabled = true;
            
            setTimeout(() => {
                showNotification('Спасибо за подписку! Проверьте вашу почту для подтверждения.', 'success');
                emailInput.value = '';
                submitBtn.innerHTML = 'Подписаться';
                submitBtn.disabled = false;
            }, 2000);
        } else {
            showNotification('Пожалуйста, введите корректный email адрес', 'warning');
            emailInput.classList.add('shake');
            setTimeout(() => emailInput.classList.remove('shake'), 500);
        }
    });
}

// Cookie Consent
function initCookieConsent() {
    const cookieConsent = document.querySelector('.cookie-consent');
    const acceptBtn = document.querySelector('.cookie-accept');
    const declineBtn = document.querySelector('.cookie-decline');
    
    // Check if user has already made a choice
    if (!localStorage.getItem('cookieConsent')) {
        setTimeout(() => {
            cookieConsent.classList.add('show');
        }, 2000);
    }
    
    acceptBtn.addEventListener('click', function() {
        localStorage.setItem('cookieConsent', 'accepted');
        cookieConsent.classList.remove('show');
    });
    
    declineBtn.addEventListener('click', function() {
        localStorage.setItem('cookieConsent', 'declined');
        cookieConsent.classList.remove('show');
    });
}

// Auth System
function initAuthSystem() {
    const loginModal = document.querySelector('#login-modal');
    const forgotModal = document.querySelector('#forgot-modal');
    const profileModal = document.querySelector('#profile-modal');
    
    // Tab switching
    const authTabs = document.querySelectorAll('.auth-tab');
    const authForms = document.querySelectorAll('.auth-form');
    
    authTabs.forEach(tab => {
        tab.addEventListener('click', function() {
            const targetTab = this.dataset.tab;
            
            // Update tabs
            authTabs.forEach(t => t.classList.remove('active'));
            this.classList.add('active');
            
            // Update forms
            authForms.forEach(form => {
                form.classList.remove('active');
                if (form.id === `${targetTab}-form`) {
                    form.classList.add('active');
                }
            });
        });
    });
    
    // Login form
    document.querySelector('#login-form').addEventListener('submit', function(e) {
        e.preventDefault();
        const email = this.querySelector('input[type="email"]').value;
        const password = this.querySelector('input[type="password"]').value;
        
        if (loginUser(email, password)) {
            showNotification('Вход выполнен успешно!', 'success');
            closeAllModals();
            updateUIAfterAuth();
        } else {
            showNotification('Неверный email или пароль', 'error');
        }
    });
    
    // Register form
    document.querySelector('#register-form').addEventListener('submit', function(e) {
        e.preventDefault();
        const email = this.querySelector('input[type="email"]').value;
        const password = this.querySelector('input[type="password"]').value;
        const confirmPassword = this.querySelectorAll('input[type="password"]')[1].value;
        const firstName = this.querySelector('input[type="text"]').value;
        const lastName = this.querySelectorAll('input[type="text"]')[1].value;
        const role = this.querySelector('select').value;
        
        if (password !== confirmPassword) {
            showNotification('Пароли не совпадают', 'error');
            return;
        }
        
        if (registerUser(email, password, firstName, lastName, role)) {
            showNotification('Аккаунт успешно создан!', 'success');
            closeAllModals();
            updateUIAfterAuth();
        } else {
            showNotification('Пользователь с таким email уже существует', 'error');
        }
    });
    
    // Forgot password form
    document.querySelector('#forgot-form').addEventListener('submit', function(e) {
        e.preventDefault();
        const email = this.querySelector('input[type="email"]').value;
        showNotification(`Ссылка для восстановления отправлена на ${email}`, 'success');
        forgotModal.classList.remove('active');
    });
    
    // Logout
    document.querySelector('.logout').addEventListener('click', function() {
        logoutUser();
        showNotification('Вы вышли из системы', 'info');
        profileModal.classList.remove('active');
    });
    
    // Navigation between auth modals
    document.querySelectorAll('.forgot-password').forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            loginModal.classList.remove('active');
            forgotModal.classList.add('active');
        });
    });
    
    document.querySelectorAll('.back-to-login').forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            forgotModal.classList.remove('active');
            loginModal.classList.add('active');
        });
    });
    
    // Open profile modal
    document.querySelector('#user-avatar').addEventListener('click', function() {
        if (isAuthenticated()) {
            loadUserProfile();
            profileModal.classList.add('active');
        }
    });
}

// Auth functions
function loginUser(email, password) {
    // In real app, this would be an API call
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    const user = users.find(u => u.email === email && u.password === password);
    
    if (user) {
        localStorage.setItem('currentUser', JSON.stringify(user));
        return true;
    }
    return false;
}

function registerUser(email, password, firstName, lastName, role) {
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    
    // Check if user already exists
    if (users.find(u => u.email === email)) {
        return false;
    }
    
    const newUser = {
        id: Date.now(),
        email,
        password, // In real app, password should be hashed
        firstName,
        lastName,
        role: role || 'student',
        createdAt: new Date().toISOString(),
        lessons: 0,
        hours: 0,
        progress: 0
    };
    
    users.push(newUser);
    localStorage.setItem('users', JSON.stringify(users));
    localStorage.setItem('currentUser', JSON.stringify(newUser));
    
    return true;
}

function logoutUser() {
    localStorage.removeItem('currentUser');
    updateUIAfterAuth();
}

function isAuthenticated() {
    return localStorage.getItem('currentUser') !== null;
}

function getCurrentUser() {
    return JSON.parse(localStorage.getItem('currentUser') || 'null');
}

function updateUIAfterAuth() {
    const authButtons = document.querySelector('#auth-buttons');
    const userAvatar = document.querySelector('#user-avatar');
    
    if (isAuthenticated()) {
        authButtons.classList.add('authenticated');
        userAvatar.classList.add('authenticated');
    } else {
        authButtons.classList.remove('authenticated');
        userAvatar.classList.remove('authenticated');
    }
}

function loadUserProfile() {
    const user = getCurrentUser();
    if (!user) return;
    
    document.querySelector('#profile-name').textContent = `${user.firstName} ${user.lastName}`;
    document.querySelector('#profile-role').textContent = getRoleDisplayName(user.role);
    document.querySelector('#profile-lessons').textContent = user.lessons || 0;
    document.querySelector('#profile-hours').textContent = user.hours || 0;
    document.querySelector('#profile-progress').textContent = user.progress || '0%';
}

function getRoleDisplayName(role) {
    const roles = {
        'student': 'Ученик',
        'parent': 'Родитель',
        'tutor': 'Репетитор'
    };
    return roles[role] || 'Пользователь';
}

// Modals
function initModals() {
    const loginBtn = document.querySelector('.login-btn');
    const registerBtn = document.querySelector('.auth-buttons .cta-button');
    const modals = document.querySelectorAll('.modal');
    const modalCloses = document.querySelectorAll('.modal-close');
    
    loginBtn.addEventListener('click', function(e) {
        e.preventDefault();
        document.querySelector('#login-modal').classList.add('active');
        document.body.style.overflow = 'hidden';
    });
    
    registerBtn.addEventListener('click', function(e) {
        e.preventDefault();
        document.querySelector('#login-modal').classList.add('active');
        // Switch to register tab
        document.querySelector('.auth-tab[data-tab="register"]').click();
        document.body.style.overflow = 'hidden';
    });
    
    modalCloses.forEach(close => {
        close.addEventListener('click', closeAllModals);
    });
    
    modals.forEach(modal => {
        modal.addEventListener('click', function(e) {
            if (e.target === modal) {
                closeAllModals();
            }
        });
    });
}

function closeAllModals() {
    document.querySelectorAll('.modal').forEach(modal => {
        modal.classList.remove('active');
    });
    document.body.style.overflow = '';
}

// Back to Top Button
function initBackToTop() {
    const backToTopBtn = document.querySelector('.back-to-top');
    
    window.addEventListener('scroll', function() {
        if (window.scrollY > 500) {
            backToTopBtn.classList.add('visible');
        } else {
            backToTopBtn.classList.remove('visible');
        }
    });
    
    backToTopBtn.addEventListener('click', function() {
        window.scrollTo({
            top: 0,
            behavior: 'smooth'
        });
    });
}

// Animated Stats Counter
function initStatsCounter() {
    const statNumbers = document.querySelectorAll('.stat-number');
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                animateValue(entry.target);
                observer.unobserve(entry.target);
            }
        });
    });
    
    statNumbers.forEach(stat => observer.observe(stat));
    
    function animateValue(element) {
        const target = parseInt(element.dataset.target);
        const duration = 2000;
        const step = target / (duration / 16);
        let current = 0;
        
        const timer = setInterval(() => {
            current += step;
            if (current >= target) {
                element.textContent = target;
                clearInterval(timer);
            } else {
                element.textContent = Math.floor(current);
            }
        }, 16);
    }
}

// Online Status Simulation
function initOnlineStatus() {
    const onlineCount = document.querySelector('#online-count');
    
    // Simulate changing online count
    setInterval(() => {
        const current = parseInt(onlineCount.textContent);
        const change = Math.floor(Math.random() * 10) - 3; // -3 to +6
        const newCount = Math.max(100, current + change);
        onlineCount.textContent = newCount;
    }, 10000);
}

// Blog Articles
function initBlogArticles() {
    const blogCards = document.querySelectorAll('.blog-card');
    const blogModal = document.querySelector('#blog-modal');
    
    // Blog articles data
    const articles = {
        1: {
            category: 'Советы',
            title: 'Как эффективно подготовиться к ЕГЭ по математике',
            date: '15 дек 2024',
            readTime: '5 мин чтения',
            image: 'data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="800" height="400" viewBox="0 0 800 400"><rect width="800" height="400" fill="%232563eb" opacity="0.1"/><text x="50%" y="50%" dominant-baseline="middle" text-anchor="middle" font-family="Arial" font-size="32" fill="%232563eb">Подготовка к ЕГЭ</text></svg>',
            content: `
                <h3>Планирование - ключ к успеху</h3>
                <p>Подготовка к ЕГЭ по математике требует системного подхода. Начните с анализа своих сильных и слабых сторон. Составьте план занятий на каждый день, уделяя внимание всем разделам экзамена.</p>
                
                <h3>Основные разделы математики</h3>
                <ul>
                    <li><strong>Алгебра</strong> - уравнения, неравенства, системы</li>
                    <li><strong>Геометрия</strong> - планиметрия и стереометрия</li>
                    <li><strong>Начала математического анализа</strong> - производные и интегралы</li>
                    <li><strong>Теория вероятностей</strong> - комбинаторика и статистика</li>
                </ul>
                
                <h3>Эффективные методы подготовки</h3>
                <p>Регулярное решение задач из открытого банка ФИПИ поможет вам привыкнуть к формату экзамена. Не забывайте про повторение пройденного материала и работу над ошибками.</p>
                
                <blockquote>
                    "Математика - это язык, на котором написана книга природы." - Галилео Галилей
                </blockquote>
                
                <h3>Советы по тайм-менеджменту</h3>
                <p>Распределите время на экзамене wisely: первые задания решайте быстро, оставляя больше времени для сложных задач второй части.</p>
            `
        },
        2: {
            category: 'Обучение',
            title: 'Преимущества онлайн-репетиторства в 2024 году',
            date: '10 дек 2024',
            readTime: '7 мин чтения',
            image: 'data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="800" height="400" viewBox="0 0 800 400"><rect width="800" height="400" fill="%232563eb" opacity="0.1"/><text x="50%" y="50%" dominant-baseline="middle" text-anchor="middle" font-family="Arial" font-size="32" fill="%232563eb">Онлайн обучение</text></svg>',
            content: `
                <h3>Гибкость и доступность</h3>
                <p>Онлайн-репетиторство позволяет заниматься из любой точки мира в удобное для вас время. Больше не нужно тратить время на дорогу - все занятия проходят в комфортной обстановке.</p>
                
                <h3>Индивидуальный подход</h3>
                <p>Цифровые технологии позволяют репетиторам адаптировать материалы под конкретные потребности каждого ученика. Интерактивные доски, онлайн-тесты и персонализированные задания делают обучение более эффективным.</p>
                
                <h3>Технологические преимущества</h3>
                <ul>
                    <li>Запись занятий для повторения</li>
                    <li>Интерактивные учебные материалы</li>
                    <li>Мгновенная проверка домашних заданий</li>
                    <li>Доступ к дополнительным ресурсам</li>
                </ul>
                
                <h3>Экономическая выгода</h3>
                <p>Онлайн-занятия обычно дешевле традиционных, при этом качество обучения остается на высоком уровне. Вы экономите не только деньги, но и время.</p>
            `
        },
        3: {
            category: 'Психология',
            title: 'Как сохранить мотивацию при длительном обучении',
            date: '5 дек 2024',
            readTime: '6 мин чтения',
            image: 'data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="800" height="400" viewBox="0 0 800 400"><rect width="800" height="400" fill="%232563eb" opacity="0.1"/><text x="50%" y="50%" dominant-baseline="middle" text-anchor="middle" font-family="Arial" font-size="32" fill="%232563eb">Мотивация</text></svg>',
            content: `
                <h3>Постановка реалистичных целей</h3>
                <p>Разбейте большую цель на маленькие achievable задачи. Каждое достижение, даже небольшое, будет давать вам чувство удовлетворения и поддерживать мотивацию.</p>
                
                <h3>Создание ритуалов</h3>
                <p>Регулярность - ключ к успеху. Создайте свой ритуал подготовки к занятиям: настройте рабочее место, приготовьте все необходимое, включите фоновую музыку.</p>
                
                <h3>Методы поддержания интереса</h3>
                <ul>
                    <li>Чередуйте разные виды деятельности</li>
                    <li>Используйте игровые элементы в обучении</li>
                    <li>Находите практическое применение знаниям</li>
                    <li>Обсуждайте прогресс с репетитором</li>
                </ul>
                
                <h3>Работа с прокрастинацией</h3>
                <p>Если чувствуете сопротивление, используйте технику "помидора": 25 минут работы, 5 минут отдыха. Это помогает преодолеть начальное сопротивление.</p>
                
                <blockquote>
                    "Успех - это сумма небольших усилий, повторяющихся изо дня в день." - Роберт Коллиер
                </blockquote>
            `
        }
    };
    
    blogCards.forEach(card => {
        card.addEventListener('click', function() {
            const articleId = this.dataset.article;
            const article = articles[articleId];
            
            if (article) {
                openBlogArticle(article);
            }
        });
    });
    
    // Also make "Read more" buttons work
    document.querySelectorAll('.blog-read-more').forEach(button => {
        button.addEventListener('click', function(e) {
            e.stopPropagation();
            const card = this.closest('.blog-card');
            const articleId = card.dataset.article;
            const article = articles[articleId];
            
            if (article) {
                openBlogArticle(article);
            }
        });
    });
}

function openBlogArticle(article) {
    const modal = document.querySelector('#blog-modal');
    
    // Fill modal with article data
    document.querySelector('#modal-category').textContent = article.category;
    document.querySelector('#modal-title').textContent = article.title;
    document.querySelector('#modal-date').textContent = article.date;
    document.querySelector('#modal-time').textContent = article.readTime;
    document.querySelector('#modal-image').src = article.image;
    document.querySelector('#modal-content').innerHTML = article.content;
    
    // Show modal
    modal.classList.add('active');
    document.body.style.overflow = 'hidden';
}

// Utility Functions
function validateEmail(email) {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email);
}

function showNotification(message, type = 'info') {
    // Remove existing notifications
    const existingNotification = document.querySelector('.notification');
    if (existingNotification) {
        existingNotification.remove();
    }
    
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.innerHTML = `
        <div class="notification-content">
            <span class="notification-message">${message}</span>
            <button class="notification-close">&times;</button>
        </div>
    `;
    
    document.body.appendChild(notification);
    
    // Animate in
    setTimeout(() => {
        notification.classList.add('notification-visible');
    }, 10);
    
    // Close button functionality
    notification.querySelector('.notification-close').addEventListener('click', function() {
        notification.classList.remove('notification-visible');
        setTimeout(() => {
            notification.remove();
        }, 300);
    });
    
    // Auto remove after 5 seconds
    setTimeout(() => {
        if (notification.parentNode) {
            notification.classList.remove('notification-visible');
            setTimeout(() => {
                if (notification.parentNode) {
                    notification.remove();
                }
            }, 300);
        }
    }, 5000);
}
// Online Lesson Demo
function initLessonDemo() {
    const whiteboard = document.getElementById('demo-whiteboard');
    const ctx = whiteboard.getContext('2d');
    const toolButtons = document.querySelectorAll('.tool-btn');
    const colorPicker = document.getElementById('color-picker');
    const clearButton = document.getElementById('clear-board');
    
    let isDrawing = false;
    let lastX = 0;
    let lastY = 0;
    let currentTool = 'pen';
    let currentColor = '#2563eb';
    let lineWidth = 2;
    
    // Initialize whiteboard
    function initWhiteboard() {
        ctx.fillStyle = 'white';
        ctx.fillRect(0, 0, whiteboard.width, whiteboard.height);
        ctx.lineJoin = 'round';
        ctx.lineCap = 'round';
        ctx.lineWidth = lineWidth;
        ctx.strokeStyle = currentColor;
    }
    
    // Set whiteboard size
    function setWhiteboardSize() {
        const rect = whiteboard.getBoundingClientRect();
        whiteboard.width = rect.width;
        whiteboard.height = rect.height;
        initWhiteboard();
    }
    
    // Drawing functions
    function startDrawing(e) {
        isDrawing = true;
        [lastX, lastY] = [e.offsetX, e.offsetY];
    }
    
    function draw(e) {
        if (!isDrawing) return;
        
        ctx.beginPath();
        ctx.moveTo(lastX, lastY);
        ctx.lineTo(e.offsetX, e.offsetY);
        ctx.stroke();
        [lastX, lastY] = [e.offsetX, e.offsetY];
    }
    
    function stopDrawing() {
        isDrawing = false;
    }
    
    // Tool selection
    toolButtons.forEach(button => {
        button.addEventListener('click', function() {
            toolButtons.forEach(btn => btn.classList.remove('active'));
            this.classList.add('active');
            currentTool = this.dataset.tool;
            
            if (currentTool === 'eraser') {
                ctx.strokeStyle = 'white';
                ctx.lineWidth = 10;
            } else {
                ctx.strokeStyle = currentColor;
                ctx.lineWidth = lineWidth;
            }
        });
    });
    
    // Color picker
    colorPicker.addEventListener('input', function() {
        currentColor = this.value;
        if (currentTool === 'pen') {
            ctx.strokeStyle = currentColor;
        }
    });
    
    // Clear board
    clearButton.addEventListener('click', initWhiteboard);
    
    // Event listeners
    whiteboard.addEventListener('mousedown', startDrawing);
    whiteboard.addEventListener('mousemove', draw);
    whiteboard.addEventListener('mouseup', stopDrawing);
    whiteboard.addEventListener('mouseout', stopDrawing);
    
    // Touch events for mobile
    whiteboard.addEventListener('touchstart', (e) => {
        e.preventDefault();
        const touch = e.touches[0];
        const mouseEvent = new MouseEvent('mousedown', {
            clientX: touch.clientX,
            clientY: touch.clientY
        });
        whiteboard.dispatchEvent(mouseEvent);
    });
    
    whiteboard.addEventListener('touchmove', (e) => {
        e.preventDefault();
        const touch = e.touches[0];
        const mouseEvent = new MouseEvent('mousemove', {
            clientX: touch.clientX,
            clientY: touch.clientY
        });
        whiteboard.dispatchEvent(mouseEvent);
    });
    
    whiteboard.addEventListener('touchend', () => {
        const mouseEvent = new MouseEvent('mouseup');
        whiteboard.dispatchEvent(mouseEvent);
    });
    
    // Initialize
    setWhiteboardSize();
    window.addEventListener('resize', setWhiteboardSize);
    
    // Chat functionality
    const chatInput = document.querySelector('.chat-input input');
    const sendButton = document.querySelector('.send-btn');
    const chatMessages = document.querySelector('.chat-messages');
    
    function sendMessage() {
        const message = chatInput.value.trim();
        if (message) {
            const messageElement = document.createElement('div');
            messageElement.className = 'message student-message';
            messageElement.innerHTML = `
                <div class="message-avatar">
                    <i class="fas fa-user"></i>
                </div>
                <div class="message-content">
                    <span class="message-sender">Вы</span>
                    <p>${message}</p>
                    <span class="message-time">${new Date().toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</span>
                </div>
            `;
            chatMessages.appendChild(messageElement);
            chatInput.value = '';
            chatMessages.scrollTop = chatMessages.scrollHeight;
            
            // Simulate tutor response
            setTimeout(() => {
                const responses = [
                    "Отличный вопрос! Давайте разберем его подробнее.",
                    "Правильно! Вы хорошо поняли материал.",
                    "Давайте рассмотрим этот момент на примере.",
                    "Это распространенная ошибка, давайте исправим ее."
                ];
                const response = responses[Math.floor(Math.random() * responses.length)];
                
                const tutorMessage = document.createElement('div');
                tutorMessage.className = 'message tutor-message';
                tutorMessage.innerHTML = `
                    <div class="message-avatar">
                        <i class="fas fa-user-tie"></i>
                    </div>
                    <div class="message-content">
                        <span class="message-sender">Анна Иванова</span>
                        <p>${response}</p>
                        <span class="message-time">${new Date().toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</span>
                    </div>
                `;
                chatMessages.appendChild(tutorMessage);
                chatMessages.scrollTop = chatMessages.scrollHeight;
            }, 1000);
        }
    }
    
    sendButton.addEventListener('click', sendMessage);
    chatInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            sendMessage();
        }
    });
}

// Progress Chart
function initProgressChart() {
    const ctx = document.getElementById('progressChart').getContext('2d');
    
    // Sample progress data
    const progressData = {
        labels: ['Янв', 'Фев', 'Мар', 'Апр', 'Май', 'Июн'],
        datasets: [{
            label: 'Прогресс обучения',
            data: [30, 45, 60, 75, 85, 95],
            borderColor: '#2563eb',
            backgroundColor: 'rgba(37, 99, 235, 0.1)',
            borderWidth: 2,
            fill: true,
            tension: 0.4
        }]
    };
    
    const chart = new Chart(ctx, {
        type: 'line',
        data: progressData,
        options: {
            responsive: true,
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    mode: 'index',
                    intersect: false
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    max: 100,
                    ticks: {
                        callback: function(value) {
                            return value + '%';
                        }
                    }
                }
            }
        }
    });
}

// Interactive Tests
function initInteractiveTests() {
    const testCards = document.querySelectorAll('.test-card');
    const testModal = document.getElementById('test-modal');
    const resultsModal = document.getElementById('results-modal');
    
    // Test data
    const tests = {
        math: {
            title: 'Тест по математике',
            time: 30,
            questions: [
                {
                    question: 'Чему равно значение выражения 2x + 5, если x = 3?',
                    options: ['11', '10', '12', '13'],
                    correct: 0
                },
                {
                    question: 'Какова площадь круга с радиусом 5 см?',
                    options: ['25π см²', '10π см²', '50π см²', '100π см²'],
                    correct: 0
                },
                {
                    question: 'Решите уравнение: 3x - 7 = 14',
                    options: ['x = 7', 'x = 6', 'x = 8', 'x = 9'],
                    correct: 0
                }
            ]
        },
        english: {
            title: 'Тест по английскому языку',
            time: 25,
            questions: [
                {
                    question: 'Choose the correct form: She ___ to school every day.',
                    options: ['go', 'goes', 'going', 'went'],
                    correct: 1
                },
                {
                    question: 'What is the past tense of "eat"?',
                    options: ['eated', 'ate', 'eaten', 'eating'],
                    correct: 1
                }
            ]
        },
        physics: {
            title: 'Тест по физике',
            time: 40,
            questions: [
                {
                    question: 'Что измеряется в ньютонах?',
                    options: ['Масса', 'Сила', 'Энергия', 'Мощность'],
                    correct: 1
                },
                {
                    question: 'Формула кинетической энергии:',
                    options: ['mv²/2', 'mgh', 'F*s', 'P*t'],
                    correct: 0
                }
            ]
        }
    };
    
    let currentTest = null;
    let currentQuestion = 0;
    let userAnswers = [];
    let timeLeft = 0;
    let timerInterval = null;
    
    testCards.forEach(card => {
        card.addEventListener('click', function() {
            const testType = this.dataset.test;
            startTest(testType);
        });
    });
    
    function startTest(testType) {
        currentTest = tests[testType];
        currentQuestion = 0;
        userAnswers = [];
        timeLeft = currentTest.time * 60; // Convert to seconds
        
        showTestModal();
        loadQuestion();
        startTimer();
    }
    
    function showTestModal() {
        document.getElementById('test-title').textContent = currentTest.title;
        testModal.classList.add('active');
        document.body.style.overflow = 'hidden';
    }
    
    function loadQuestion() {
        const question = currentTest.questions[currentQuestion];
        const progress = ((currentQuestion + 1) / currentTest.questions.length) * 100;
        
        document.getElementById('test-question-text').textContent = question.question;
        document.getElementById('test-progress').textContent = `Вопрос ${currentQuestion + 1} из ${currentTest.questions.length}`;
        document.getElementById('test-progress-bar').style.width = `${progress}%`;
        
        const optionsContainer = document.getElementById('test-options');
        optionsContainer.innerHTML = '';
        
        question.options.forEach((option, index) => {
            const optionElement = document.createElement('div');
            optionElement.className = 'test-option';
            optionElement.textContent = option;
            optionElement.addEventListener('click', () => selectAnswer(index));
            optionsContainer.appendChild(optionElement);
        });
        
        updateNavigationButtons();
    }
    
    function selectAnswer(answerIndex) {
        userAnswers[currentQuestion] = answerIndex;
        
        const options = document.querySelectorAll('.test-option');
        options.forEach((option, index) => {
            option.classList.toggle('selected', index === answerIndex);
        });
        
        document.getElementById('test-next').disabled = false;
    }
    
    function updateNavigationButtons() {
        document.getElementById('test-prev').disabled = currentQuestion === 0;
        document.getElementById('test-next').style.display = currentQuestion < currentTest.questions.length - 1 ? 'block' : 'none';
        document.getElementById('test-submit').style.display = currentQuestion === currentTest.questions.length - 1 ? 'block' : 'none';
    }
    
    function startTimer() {
        updateTimerDisplay();
        timerInterval = setInterval(() => {
            timeLeft--;
            updateTimerDisplay();
            
            if (timeLeft <= 0) {
                finishTest();
            }
        }, 1000);
    }
    
    function updateTimerDisplay() {
        const minutes = Math.floor(timeLeft / 60);
        const seconds = timeLeft % 60;
        document.getElementById('test-time').textContent = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
    }
    
    document.getElementById('test-next').addEventListener('click', () => {
        if (currentQuestion < currentTest.questions.length - 1) {
            currentQuestion++;
            loadQuestion();
        }
    });
    
    document.getElementById('test-prev').addEventListener('click', () => {
        if (currentQuestion > 0) {
            currentQuestion--;
            loadQuestion();
        }
    });
    
    document.getElementById('test-submit').addEventListener('click', finishTest);
    
    function finishTest() {
        clearInterval(timerInterval);
        calculateResults();
        testModal.classList.remove('active');
        resultsModal.classList.add('active');
    }
    
    function calculateResults() {
        let correctCount = 0;
        
        currentTest.questions.forEach((question, index) => {
            if (userAnswers[index] === question.correct) {
                correctCount++;
            }
        });
        
        const percentage = Math.round((correctCount / currentTest.questions.length) * 100);
        const timeSpent = currentTest.time * 60 - timeLeft;
        const minutes = Math.floor(timeSpent / 60);
        const seconds = timeSpent % 60;
        
        document.getElementById('results-percentage').textContent = `${percentage}%`;
        document.getElementById('total-questions').textContent = currentTest.questions.length;
        document.getElementById('correct-answers').textContent = correctCount;
        document.getElementById('incorrect-answers').textContent = currentTest.questions.length - correctCount;
        document.getElementById('time-spent').textContent = `${minutes}:${seconds.toString().padStart(2, '0')}`;
    }
    
    // Results modal handlers
    document.getElementById('retry-test').addEventListener('click', () => {
        resultsModal.classList.remove('active');
        startTest(Object.keys(tests).find(key => tests[key] === currentTest));
    });
    
    document.getElementById('close-results').addEventListener('click', () => {
        resultsModal.classList.remove('active');
    });
}

// Virtual Study Room
function initStudyRoom() {
    const roomButtons = document.querySelectorAll('.room-control-btn');
    const roomInput = document.querySelector('.room-input input');
    const roomSendButton = document.querySelector('.room-send-btn');
    const roomMessages = document.querySelector('.room-messages');
    
    roomButtons.forEach(button => {
        button.addEventListener('click', function() {
            roomButtons.forEach(btn => btn.classList.remove('active'));
            this.classList.add('active');
            
            // Simulate room change
            const roomName = this.dataset.room;
            simulateRoomActivity(roomName);
        });
    });
    
    function sendRoomMessage() {
        const message = roomInput.value.trim();
        if (message) {
            const messageElement = document.createElement('div');
            messageElement.className = 'room-message';
            messageElement.innerHTML = `
                <span class="message-sender">Вы:</span>
                <p>${message}</p>
            `;
            roomMessages.appendChild(messageElement);
            roomInput.value = '';
            roomMessages.scrollTop = roomMessages.scrollHeight;
            
            // Simulate response
            setTimeout(() => {
                const responses = {
                    math: [
                        "Интересный вопрос! Давайте решим его вместе.",
                        "Я тоже над этим думал. Может, попробуем другой метод?",
                        "Отличная идея! Продолжайте в том же духе."
                    ],
                    english: [
                        "Good question! Let me help you with that.",
                        "I was practicing this too. We can study together!",
                        "Your English is improving! Keep it up."
                    ],
                    programming: [
                        "Классная задача! Давайте напишем код вместе.",
                        "Я сталкивался с подобной проблемой. Могу показать решение.",
                        "Отличный подход! Можно оптимизировать вот так..."
                    ]
                };
                
                const currentRoom = document.querySelector('.room-control-btn.active').dataset.room;
                const roomResponses = responses[currentRoom] || responses.math;
                const response = roomResponses[Math.floor(Math.random() * roomResponses.length)];
                const users = ['Анна', 'Дмитрий', 'Мария', 'Сергей'];
                const randomUser = users[Math.floor(Math.random() * users.length)];
                
                const responseElement = document.createElement('div');
                responseElement.className = 'room-message';
                responseElement.innerHTML = `
                    <span class="message-sender">${randomUser}:</span>
                    <p>${response}</p>
                `;
                roomMessages.appendChild(responseElement);
                roomMessages.scrollTop = roomMessages.scrollHeight;
            }, 2000);
        }
    }
    
    roomSendButton.addEventListener('click', sendRoomMessage);
    roomInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            sendRoomMessage();
        }
    });
    
    function simulateRoomActivity(roomName) {
        roomMessages.innerHTML = `
            <div class="room-message">
                <span class="message-sender">Система:</span>
                <p>Вы вошли в комнату "${getRoomDisplayName(roomName)}"</p>
            </div>
        `;
    }
    
    function getRoomDisplayName(roomName) {
        const names = {
            math: 'Математика',
            english: 'Английский язык',
            programming: 'Программирование'
        };
        return names[roomName] || roomName;
    }
}

// Mobile App Download
function initMobileApp() {
    const downloadButtons = document.querySelectorAll('.download-btn');
    
    downloadButtons.forEach(button => {
        button.addEventListener('click', function() {
            const platform = this.querySelector('i').classList.contains('fa-google-play') ? 'Android' : 'iOS';
            showNotification(`Приложение для ${platform} скоро будет доступно для скачивания!`, 'info');
        });
    });
}

// Update main initialization
document.addEventListener('DOMContentLoaded', function() {
    // ... existing initializations ...
    
    // Add new initializations
    initLessonDemo();
    initProgressChart();
    initInteractiveTests();
    initStudyRoom();
    initMobileApp();
});